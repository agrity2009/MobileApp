package com.example.user.myproject;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class OrderAdapter extends BaseAdapter {
    private List<Order> mOrder;
    private LayoutInflater mLayoutInflater;
    public static final String TAG="myTag";

    public OrderAdapter (Context context, List<Order> ordersList){
        mOrder=ordersList;
        mLayoutInflater=LayoutInflater.from(context);
    }

    protected static class ViewHolder{
        TextView order_name;
        TextView customer;
        TextView send;
        TextView stat;
    }

    @Override
    public int getCount() {
        return mOrder.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        ViewHolder holder;
        if(view==null){
            view=mLayoutInflater.inflate(R.layout.order_row_layout,parent,false);
            holder = new ViewHolder();
            holder.order_name=(TextView)view.findViewById(R.id.order_adapter);
            holder.customer=(TextView)view.findViewById(R.id.Customer_adapter);
            holder.send=(TextView)view.findViewById(R.id.Send_adapter);
            holder.stat=(TextView)view.findViewById(R.id.stat_adapter);
            view.setTag(holder);
        }
        else {
            holder=(ViewHolder)view.getTag();
        }
        holder.order_name.setText(mOrder.get(position).getOrder_name());
        holder.customer.setText("คุณ "+mOrder.get(position).getCustomer_name()+"  "+mOrder.get(position).getCustomer_surname());
        holder.send.setText("วันที่ส่ง :"+mOrder.get(position).getDay_send()+"/"+mOrder.get(position).getMonth_send()+"/"+mOrder.get(position).getYear_send());
        holder.stat.setText("สถานะ :"+mOrder.get(position).getOrder_status());
        holder.order_name.setTextColor(Color.BLACK);
        holder.customer.setTextColor(Color.BLACK);
        holder.send.setTextColor(Color.BLACK);
        if(mOrder.get(position).getOrder_status().equals("Incomplete")){
            holder.stat.setTextColor(Color.RED);
        }
        else{
            holder.stat.setTextColor(Color.GREEN);
        }

        return view;
    }
}
