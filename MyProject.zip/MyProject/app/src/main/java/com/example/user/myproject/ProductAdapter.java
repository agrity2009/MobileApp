package com.example.user.myproject;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ProductAdapter extends BaseAdapter {

    private List<Product> mProduct;
    private LayoutInflater mLayoutInflater;

    public ProductAdapter (Context context,List<Product> productList){
        mProduct=productList;
        mLayoutInflater=LayoutInflater.from(context);
    }

    protected static class ViewHolder{
        TextView Product_name;
        ImageView Product_img;
        TextView Product_price;

    }

    @Override
    public int getCount() {
        return mProduct.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        ViewHolder holder;
        if(view==null){
            view=mLayoutInflater.inflate(R.layout.product_row_layout,parent,false);
            holder = new ViewHolder();
            holder.Product_img=(ImageView)view.findViewById(R.id.product_image_adapter);
            holder.Product_name=(TextView)view.findViewById(R.id.product_name_adapter);
            holder.Product_price=(TextView)view.findViewById(R.id.product_price2);
            view.setTag(holder);
        }
        else {
            holder=(ViewHolder)view.getTag();
        }
    holder.Product_name.setText(""+mProduct.get(position).getProduct_name());
    holder.Product_price.setText(""+mProduct.get(position).getPrice());
    holder.Product_img.setImageBitmap(Product.getImage(mProduct.get(position).getProduct_imageBytes()));
    holder.Product_name.setTextColor(Color.BLACK);
    holder.Product_price.setTextColor(Color.BLACK);
        return view;
    }
}
