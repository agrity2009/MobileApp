package com.example.user.myproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

public class DataBaseHelper extends SQLiteOpenHelper {
    private static final int DB_VERSION=1;
    private static final String DB_NAME="?ํMY_DATABASE";
    private static final String TABLE_PRODUCT_NAME="Products";
    private static final String TABLE_ORDER_NAME="Orders";
    private static final String col_product_1="Product_ID";
    private static final String col_product_2="Product_Name";
    private static final String col_product_3="Product_Detail";
    private static final String col_product_4="Price";
    private static final String col_product_5="Product_Image";
    private static final String Create_table_product_string="CREATE TABLE "+TABLE_PRODUCT_NAME+
            " (" +col_product_1+" INTEGER PRIMARY KEY,"+
            col_product_2+" TEXT(50),"+
            col_product_3+" TEXT(250),"+
            col_product_4+" REAL,"+
            col_product_5+" BLOB)";
    //private static final String Drop_table_product_string="DROP TABLE IF EXISTS "+TABLE_PRODUCT_NAME;
    private static final String col_order_1="Order_ID";
    private static final String col_order_2="Order_Name";
    private static final String col_order_3="Customer_firstName";
    private static final String col_order_4="Customer_lastName";
    private static final String col_order_5="Customer_Address";
    private static final String col_order_6="Customer_Phone";
    private static final String col_order_7="Product_Name";
    private static final String col_order_8="Product_Quantity";
    private static final String col_order_9="Total_Price";
    private static final String col_order_10="Order_DateDay_Create";
    private static final String col_order_11="Order_DateMonth_Create";
    private static final String col_order_12="Order_DateYear_Create";
    private static final String col_order_13="Order_DateDay_Send";
    private static final String col_order_14="Order_DateMonth_Send";
    private static final String col_order_15="Order_DateYear_Send";
    private static final String col_order_16="Order_Status";
    private static final String Create_table_order_string="CREATE TABLE "+TABLE_ORDER_NAME+
            " (" +col_order_1+" INTEGER PRIMARY KEY,"+
            col_order_2+" TEXT(50),"+
            col_order_3+" TEXT(50),"+
            col_order_4+" TEXT(50),"+
            col_order_5+" TEXT(100),"+
            col_order_6+" TEXT(15),"+
            col_order_7+" TEXT(50),"+
            col_order_8+" INTEGER,"+
            col_order_9+" REAL,"+
            col_order_10+" INTEGER,"+
            col_order_11+" INTEGER,"+
            col_order_12+" INTEGER,"+
            col_order_13+" INTEGER,"+
            col_order_14+" INTEGER,"+
            col_order_15+" INTEGER,"+
            col_order_16+" TEXT(20))";
    private static SQLiteDatabase sqLiteDatabase;
    private static SQLiteDatabase sqLiteDatabase2;
    public static final String TAG="myTag";

    public DataBaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(Create_table_product_string);
        db.execSQL(Create_table_order_string);
        Log.i(TAG,Create_table_product_string);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_PRODUCT_NAME);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_ORDER_NAME);
        onCreate(db);
    }



    public void addProduct(Product product){
        sqLiteDatabase=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(col_product_1,product.getProduct_id());
        values.put(col_product_2,product.getProduct_name());
        values.put(col_product_3,product.getProduct_detail());
        values.put(col_product_4,product.getPrice());
        values.put(col_product_5,product.getProduct_imageBytes());
        sqLiteDatabase.insert(TABLE_PRODUCT_NAME,null,values);
        Log.i(TAG,"onAddProduct");
        sqLiteDatabase.close();
    }

    public void addOrder(Order order){
        sqLiteDatabase=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(col_order_1,order.getOrder_id());
        values.put(col_order_2,order.getOrder_name());
        values.put(col_order_3,order.getCustomer_name());
        values.put(col_order_4,order.getCustomer_surname());
        values.put(col_order_5,order.getCustomer_address());
        values.put(col_order_6,order.getCustomer_phone());
        values.put(col_order_7,order.getOrder_product());
        values.put(col_order_8,order.getQuantity());
        values.put(col_order_9,order.getTotal_price());
        values.put(col_order_10,order.getDay_order());
        values.put(col_order_11,order.getMonth_order());
        values.put(col_order_12,order.getYear_order());
        values.put(col_order_13,order.getDay_send());
        values.put(col_order_14,order.getMonth_send());
        values.put(col_order_15,order.getYear_send());
        values.put(col_order_16,order.getOrder_status());
        sqLiteDatabase.insert(TABLE_ORDER_NAME,null,values);
        sqLiteDatabase.close();
    }

    public ArrayList<Product> readAllProducts(){
        int i=1;
        ArrayList<Product> list=new ArrayList<>();
        sqLiteDatabase=this.getReadableDatabase();
        ContentValues values=new ContentValues();
        Cursor cur=sqLiteDatabase.query(TABLE_PRODUCT_NAME,null,null,null,null,null,null);
        Log.i(TAG,"onCurProduct size is "+cur.getCount());
        if (cur.getCount()!=0&&cur.moveToFirst()){
            int idColum=cur.getColumnIndex(col_product_1);
            int nameColum=cur.getColumnIndex(col_product_2);
            int detailColum=cur.getColumnIndex(col_product_3);
            int priceColum=cur.getColumnIndex(col_product_4);
            int imgColum=cur.getColumnIndex(col_product_5);
            do {
                Product product_model = new Product();
                product_model.setProduct_id(cur.getInt(idColum));
                product_model.setProduct_name(cur.getString(nameColum));
                product_model.setProduct_detail(cur.getString(detailColum));
                product_model.setPrice(cur.getDouble(priceColum));
                product_model.setProduct_imageBytes(cur.getBlob(imgColum));
                list.add(product_model);
            } while (cur.moveToNext());
            cur.close();
        }
        Log.i(TAG,"onReadAll Product size is "+list.size());
        sqLiteDatabase.close();
        return list;
    }

    public ArrayList<Order> readAllOrders(){
        int i=1;
        ArrayList<Order> list=new ArrayList<>();
        sqLiteDatabase=this.getReadableDatabase();
        ContentValues values=new ContentValues();
        Cursor cur=sqLiteDatabase.query(TABLE_ORDER_NAME,null,null,null,null,null,null);
        Log.i(TAG,"onCurOrder Order size is "+cur.getCount());
        if (cur.getCount()!=0&&cur.moveToFirst()){
            int idColum=cur.getColumnIndex(col_order_1);
            int nameOrderColum=cur.getColumnIndex(col_order_2);
            int FirstnameColum=cur.getColumnIndex(col_order_3);
            int LastnameColum=cur.getColumnIndex(col_order_4);
            int AddressColum=cur.getColumnIndex(col_order_5);
            int PhoneColum=cur.getColumnIndex(col_order_6);
            int ProductNameColum=cur.getColumnIndex(col_order_7);
            int QuantityColum=cur.getColumnIndex(col_order_8);
            int TotalColum=cur.getColumnIndex(col_order_9);
            int DayCreateColum=cur.getColumnIndex(col_order_10);
            int MonthCreateColum=cur.getColumnIndex(col_order_11);
            int YearCreateColum=cur.getColumnIndex(col_order_12);
            int DaySendColum=cur.getColumnIndex(col_order_13);
            int MonthSendColum=cur.getColumnIndex(col_order_14);
            int YearSendColum=cur.getColumnIndex(col_order_15);
            int StatusColum=cur.getColumnIndex(col_order_16);
            do {
                Order order_model = new Order();
                order_model.setOrder_id(cur.getInt(idColum));
                order_model.setOrder_name(cur.getString(nameOrderColum));
                order_model.setCustomer_name(cur.getString(FirstnameColum));
                order_model.setCustomer_surname(cur.getString(LastnameColum));
                order_model.setCustomer_address(cur.getString(AddressColum));
                order_model.setCustomer_phone(cur.getString(PhoneColum));
                order_model.setOrder_product(cur.getString(ProductNameColum));
                order_model.setQuantity(cur.getInt(QuantityColum));
                order_model.setTotal_price(cur.getDouble(TotalColum));
                order_model.setDay_order(cur.getInt(DayCreateColum));
                order_model.setMonth_order(cur.getInt(MonthCreateColum));
                order_model.setYear_order(cur.getInt(YearCreateColum));
                order_model.setDay_send(cur.getInt(DaySendColum));
                order_model.setMonth_send(cur.getInt(MonthSendColum));
                order_model.setYear_send(cur.getInt(YearSendColum));
                order_model.setOrder_status(cur.getString(StatusColum));
                list.add(order_model);
            } while (cur.moveToNext());
            cur.close();
        }
        Log.i(TAG,"onReadAll Order size is "+list.size());
        sqLiteDatabase.close();
        return list;
    }

    public Product getSearchedRecord(int id){
        id=id+1;
        Product selectedProduct=new Product();
        sqLiteDatabase=this.getWritableDatabase();
        Cursor cur=sqLiteDatabase.query(TABLE_PRODUCT_NAME,null,col_product_1+" =?",new String[]{String.valueOf(id)},null,null,null);
        if(cur.getCount()!=0&&cur.moveToFirst()){
            int idColum=cur.getColumnIndex(col_product_1);
            int nameColum=cur.getColumnIndex(col_product_2);
            int detailColum=cur.getColumnIndex(col_product_3);
            int priceColum=cur.getColumnIndex(col_product_4);
            int imgColum=cur.getColumnIndex(col_product_5);
            selectedProduct.setProduct_id(cur.getInt(idColum));
            selectedProduct.setProduct_name(cur.getString(nameColum));
            selectedProduct.setProduct_detail(cur.getString(detailColum));
            selectedProduct.setPrice(cur.getDouble(priceColum));
            selectedProduct.setProduct_imageBytes(cur.getBlob(imgColum));
        }
        sqLiteDatabase.close();
        Log.i(TAG,"onGetProduct");
        return selectedProduct;
    }
    public Order getSearchedOrderRecord(int id){
        id=id+1;
        Order selectedOrder=new Order();
        sqLiteDatabase=this.getWritableDatabase();
        Cursor cur=sqLiteDatabase.query(TABLE_ORDER_NAME,null,col_order_1+" =?",new String[]{String.valueOf(id)},null,null,null);
        if(cur.getCount()!=0&&cur.moveToFirst()){
            int idColum=cur.getColumnIndex(col_order_1);
            int nameOrderColum=cur.getColumnIndex(col_order_2);
            int FirstnameColum=cur.getColumnIndex(col_order_3);
            int LastnameColum=cur.getColumnIndex(col_order_4);
            int AddressColum=cur.getColumnIndex(col_order_5);
            int PhoneColum=cur.getColumnIndex(col_order_6);
            int ProductNameColum=cur.getColumnIndex(col_order_7);
            int QuantityColum=cur.getColumnIndex(col_order_8);
            int TotalColum=cur.getColumnIndex(col_order_9);
            int DayCreateColum=cur.getColumnIndex(col_order_10);
            int MonthCreateColum=cur.getColumnIndex(col_order_11);
            int YearCreateColum=cur.getColumnIndex(col_order_12);
            int DaySendColum=cur.getColumnIndex(col_order_13);
            int MonthSendColum=cur.getColumnIndex(col_order_14);
            int YearSendColum=cur.getColumnIndex(col_order_15);
            int StatusColum=cur.getColumnIndex(col_order_16);
            selectedOrder.setOrder_id(cur.getInt(idColum));
            selectedOrder.setOrder_name(cur.getString(nameOrderColum));
            selectedOrder.setCustomer_name(cur.getString(FirstnameColum));
            selectedOrder.setCustomer_surname(cur.getString(LastnameColum));
            selectedOrder.setCustomer_address(cur.getString(AddressColum));
            selectedOrder.setCustomer_phone(cur.getString(PhoneColum));
            selectedOrder.setOrder_product(cur.getString(ProductNameColum));
            selectedOrder.setQuantity(cur.getInt(QuantityColum));
            selectedOrder.setTotal_price(cur.getDouble(TotalColum));
            selectedOrder.setDay_order(cur.getInt(DayCreateColum));
            selectedOrder.setMonth_order(cur.getInt(MonthCreateColum));
            selectedOrder.setYear_order(cur.getInt(YearCreateColum));
            selectedOrder.setDay_send(cur.getInt(DaySendColum));
            selectedOrder.setMonth_send(cur.getInt(MonthSendColum));
            selectedOrder.setYear_send(cur.getInt(YearSendColum));
            selectedOrder.setOrder_status(cur.getString(StatusColum));
        }
        sqLiteDatabase.close();
        Log.i(TAG,"onGetProduct");
        return selectedOrder;
    }
    public void deleteProduct(int id){
        sqLiteDatabase=this.getWritableDatabase();
        sqLiteDatabase.delete(TABLE_PRODUCT_NAME, col_product_1+" = "+id,null);
        Log.i(TAG,"onDeleteProduct");
        sqLiteDatabase.close();
    }
    public void deleteOrder(int id){
        sqLiteDatabase=this.getWritableDatabase();
        sqLiteDatabase.delete(TABLE_ORDER_NAME, col_order_1+" = "+id,null);
        Log.i(TAG,"onDeleteProduct");
        sqLiteDatabase.close();
    }
    public void editProduct(Product edit_product){
        sqLiteDatabase=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(col_product_1,edit_product.getProduct_id());
        values.put(col_product_2,edit_product.getProduct_name());
        values.put(col_product_3,edit_product.getProduct_detail());
        values.put(col_product_4,edit_product.getPrice());
        values.put(col_product_5,edit_product.getProduct_imageBytes());
        sqLiteDatabase.update(TABLE_PRODUCT_NAME,values,col_product_1+" = "+String.valueOf(edit_product.getProduct_id()),null);
        sqLiteDatabase.close();
    }
    public void editOrder(Order edit_order){
        sqLiteDatabase=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(col_order_1,edit_order.getOrder_id());
        values.put(col_order_2,edit_order.getOrder_name());
        values.put(col_order_3,edit_order.getCustomer_name());
        values.put(col_order_4,edit_order.getCustomer_surname());
        values.put(col_order_5,edit_order.getCustomer_address());
        values.put(col_order_6,edit_order.getCustomer_phone());
        values.put(col_order_7,edit_order.getOrder_product());
        values.put(col_order_8,edit_order.getQuantity());
        values.put(col_order_9,edit_order.getTotal_price());
        values.put(col_order_10,edit_order.getDay_order());
        values.put(col_order_11,edit_order.getMonth_order());
        values.put(col_order_12,edit_order.getYear_order());
        values.put(col_order_13,edit_order.getDay_send());
        values.put(col_order_14,edit_order.getMonth_send());
        values.put(col_order_15,edit_order.getYear_send());
        values.put(col_order_16,edit_order.getOrder_status());
        sqLiteDatabase.update(TABLE_ORDER_NAME,values,col_order_1+" = "+String.valueOf(edit_order.getOrder_id()),null);
        sqLiteDatabase.close();
    }
    public void updateListProducts(Product oldProduct,Product newProduct){
        sqLiteDatabase=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(col_product_1,newProduct.getProduct_id());
        values.put(col_product_2,newProduct.getProduct_name());
        values.put(col_product_3,newProduct.getProduct_detail());
        values.put(col_product_4,newProduct.getPrice());
        values.put(col_product_5,newProduct.getProduct_imageBytes());
        Log.i(TAG,"old Product ID :"+oldProduct.getProduct_id());
        Log.i(TAG,"new Product ID :"+newProduct.getProduct_id());
        sqLiteDatabase.update(TABLE_PRODUCT_NAME,values,col_product_1+" = "+String.valueOf(oldProduct.getProduct_id()),null);
        Log.i(TAG,"onUpdateProduct");
    }
    public void updateListOrders(Order oldOrder,Order newOrder){
        sqLiteDatabase=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(col_order_1,newOrder.getOrder_id());
        values.put(col_order_2,newOrder.getOrder_name());
        values.put(col_order_3,newOrder.getCustomer_name());
        values.put(col_order_4,newOrder.getCustomer_surname());
        values.put(col_order_5,newOrder.getCustomer_address());
        values.put(col_order_6,newOrder.getCustomer_phone());
        values.put(col_order_7,newOrder.getOrder_product());
        values.put(col_order_8,newOrder.getQuantity());
        values.put(col_order_9,newOrder.getTotal_price());
        values.put(col_order_10,newOrder.getDay_order());
        values.put(col_order_11,newOrder.getMonth_order());
        values.put(col_order_12,newOrder.getYear_order());
        values.put(col_order_13,newOrder.getDay_send());
        values.put(col_order_14,newOrder.getMonth_send());
        values.put(col_order_15,newOrder.getYear_send());
        values.put(col_order_16,newOrder.getOrder_status());
        sqLiteDatabase.update(TABLE_ORDER_NAME,values,col_order_1+" = "+String.valueOf(oldOrder.getOrder_id()),null);
        Log.i(TAG,"onUpdateProduct");
    }


    public int getCountProduct(){
        String countQuery="select "+col_product_1+" from "+TABLE_PRODUCT_NAME;
        sqLiteDatabase=this.getReadableDatabase();
        Cursor cur=sqLiteDatabase.rawQuery(countQuery,null);
        return cur.getCount();
    }

    public int getCountOrder(){
        String countQuery="select "+col_order_1+" from "+TABLE_ORDER_NAME;
        sqLiteDatabase=this.getReadableDatabase();
        Cursor cur=sqLiteDatabase.rawQuery(countQuery,null);
        return cur.getCount();
    }



}
