package com.example.user.myproject;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class Show_Activity extends AppCompatActivity {
    private static final String Tag="myTag";
    private TextView product_name;
    private TextView product_detail;
    private TextView product_price;
    private ImageView product_image;
    private Button delete_button;
    private Button edit_button;
    private DataBaseHelper mHelper;
    private int position;
    private Product mProduct;
    private List<Product> oldProductList,newProductList;
    private Intent itn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_);
        mHelper=new DataBaseHelper(this);
        position=getIntent().getIntExtra("key",0);
        mProduct=mHelper.getSearchedRecord(position);
        product_name=(TextView)findViewById(R.id.product_name_show_txt2);
        product_detail=(TextView)findViewById(R.id.product_detail_show_txt2);
        product_price=(TextView)findViewById(R.id.product_price_show_txt2);
        product_image=(ImageView)findViewById(R.id.product_image_show);
        delete_button=(Button)findViewById(R.id.Delete_Product_Button);
        edit_button=(Button)findViewById((R.id.Edit_Product_Button));

        product_name.setText("ชื่อสินค้า "+mProduct.getProduct_name());
        product_name.setTextColor(Color.BLACK);
        product_detail.setText("รายละเอียด "+mProduct.getProduct_detail());
        product_detail.setTextColor(Color.BLACK);
        product_price.setText("ราคา "+String.valueOf(mProduct.getPrice())+"บาท");
        product_price.setTextColor(Color.BLACK);
        product_image.setImageBitmap(Product.getImage(mProduct.getProduct_imageBytes()));

        delete_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Show_Activity.this);
                //แจ้งเตือนเพิ่มข้อมูล ส่วนที่เป็น Title
                builder.setTitle("Delete this product?");
                //แจ้งเตือนเพิ่มข้อมูล ส่วนที่เป็น Message
                builder.setMessage("Are you sure?");

                builder.setPositiveButton(getString(android.R.string.ok), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mHelper.deleteProduct(mProduct.getProduct_id());
                        oldProductList=mHelper.readAllProducts();
                        newProductList=mHelper.readAllProducts();
                        for(int i=0;i<newProductList.size();i++){
                            newProductList.get(i).setProduct_id(i+1);
                            mHelper.updateListProducts(oldProductList.get(i),newProductList.get(i));
                        }
                        finish();
                    }
                });
                //ปุ่ม Cancel
                builder.setNegativeButton(getString(android.R.string.cancel), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.show();

            }
        });
        edit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent itn=new Intent(getApplicationContext(),Edit_Product_Activity.class);
                itn.putExtra("key",position);
                startActivity(itn);

            }
        });
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if(id==android.R.id.home){
            //end the activity
            this.finish();
        }
        return super.onOptionsItemSelected(item);

    }
}
