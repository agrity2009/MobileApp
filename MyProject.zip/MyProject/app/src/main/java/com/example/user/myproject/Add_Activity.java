package com.example.user.myproject;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import java.io.FileNotFoundException;
import java.io.IOException;


public class Add_Activity extends AppCompatActivity {
    private ImageButton product_img;
    private EditText product_name;
    private EditText product_detail;
    private EditText price;
    private Button submit;
    private DataBaseHelper mHelper;
    private int REQUSE_CODE = 1;
    private Bitmap Image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_);
        this.product_img=(ImageButton) findViewById(R.id.add_product_image);
        this.product_name=(EditText)findViewById(R.id.add_product_name_edit);
        this.product_detail=(EditText)findViewById(R.id.add_product_detail_edit);
        this.price=(EditText)findViewById(R.id.add_product_price_edit);
        this.submit=(Button)findViewById(R.id.InsertBtn);
        mHelper=new DataBaseHelper(this);

        Image=BitmapFactory.decodeResource(getResources(),R.drawable.add_icon);
        product_img.setImageBitmap(Image);
        //ปุ่ม บันทึก setOnclickListener
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder=new AlertDialog.Builder(Add_Activity.this);
                //แจ้งเตือนเพิ่มข้อมูล ส่วนที่เป็น Title
                builder.setTitle(getString(R.string.insert_product_title));
                //แจ้งเตือนเพิ่มข้อมูล ส่วนที่เป็น Message
                builder.setMessage(getString(R.string.Insert_product_message));
                //ปุ่ม OK
                builder.setPositiveButton(getString(android.R.string.ok), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Product product=new Product();
                        product.setProduct_id(mHelper.getCountProduct()+1);
                        product.setProduct_name(product_name.getText().toString());
                        product.setProduct_detail(product_detail.getText().toString());
                        product.setPrice(Double.parseDouble(price.getText().toString()));
                        product.setProduct_imageBytes(Product.getBytes(Image));
                        mHelper.addProduct(product);
                        finish();
                    }
                }
                );
                //ปุ่ม Cancel
                builder.setNegativeButton(getString(android.R.string.cancel), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });

        product_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent itn=new Intent();
                itn.setType("image/*");
                itn.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(itn,"Select Image"),REQUSE_CODE);
            }
        });
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if(id==android.R.id.home){
            //end the activity
            this.finish();
        }
        return super.onOptionsItemSelected(item);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==REQUSE_CODE && resultCode==RESULT_OK && data!=null && data.getData()!=null){
            Uri uri=data.getData();
            try {
                Image=MediaStore.Images.Media.getBitmap(getContentResolver(),uri);
                product_img.setImageBitmap(Image);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
