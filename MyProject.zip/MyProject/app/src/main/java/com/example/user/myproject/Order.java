package com.example.user.myproject;

public class Order {
    private int order_id;
    private String order_name;
    private String customer_name;
    private String customer_surname;
    private String customer_address;
    private String customer_phone;
    private String order_product;
    private int quantity;
    private double total_price;
    private int day_order;
    private int month_order;
    private int year_order;
    private int day_send;
    private int month_send;
    private int year_send;
    private String order_status;

    public Order(){

    }

    public String getOrder_name() {
        return order_name;
    }

    public void setOrder_name(String order_name) {
        this.order_name = order_name;
    }

    public String getCustomer_phone() {
        return customer_phone;
    }

    public void setCustomer_phone(String customer_phone) {
        this.customer_phone = customer_phone;
    }

    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    public String getCustomer_surname() {
        return customer_surname;
    }

    public void setCustomer_surname(String customer_surname) {
        this.customer_surname = customer_surname;
    }

    public String getCustomer_address() {
        return customer_address;
    }

    public void setCustomer_address(String customer_address) {
        this.customer_address = customer_address;
    }

    public String getOrder_product() {
        return order_product;
    }

    public void setOrder_product(String order_product) {
        this.order_product = order_product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Double getTotal_price() {
        return total_price;
    }

    public void setTotal_price(double total_price) {
        this.total_price = total_price;
    }

    public int getDay_order() {
        return day_order;
    }

    public void setDay_order(int day_order) {
        this.day_order = day_order;
    }

    public int getMonth_order() {
        return month_order;
    }

    public void setMonth_order(int month_order) {
        this.month_order = month_order;
    }

    public int getYear_order() {
        return year_order;
    }

    public void setYear_order(int year_order) {
        this.year_order = year_order;
    }

    public int getDay_send() {
        return day_send;
    }

    public void setDay_send(int day_send) {
        this.day_send = day_send;
    }

    public int getMonth_send() {
        return month_send;
    }

    public void setMonth_send(int month_send) {
        this.month_send = month_send;
    }

    public int getYear_send() {
        return year_send;
    }

    public void setYear_send(int year_send) {
        this.year_send = year_send;
    }

    public String getOrder_status() {
        return order_status;
    }

    public void setOrder_status(String order_status) {
        this.order_status = order_status;
    }
}
