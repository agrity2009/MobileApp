package com.example.user.myproject;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;


public class Add_Order_Activity extends AppCompatActivity {

    private EditText orderName;
    private EditText customerfirstName;
    private EditText customerlastName;
    private EditText customerAddress;
    private EditText customerPhone;
    private Spinner productName;
    private EditText productQuantity;
    private TextView DateCreate;
    private TextView DateSend;
    private Button submit;
    private DataBaseHelper mHelper;
    private Order insertOrder;
    private List<Product> list=new ArrayList<>();
    private List<String> product_list=new ArrayList<>();
    private GregorianCalendar CurrentDay;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add__order_);
        orderName = (EditText) findViewById(R.id.order_name_edit);
        customerfirstName = (EditText) findViewById(R.id.customer_firstname_edit);
        customerlastName = (EditText) findViewById(R.id.customer_lastname_edit);
        customerAddress = (EditText) findViewById(R.id.customer_address_edit);
        customerPhone = (EditText) findViewById(R.id.customer_phone_edit);
        productName = (Spinner) findViewById(R.id.customer_product_name);
        productQuantity = (EditText) findViewById(R.id.product_quantity_edit);
        DateCreate = (TextView) findViewById(R.id.product_date_order_show);
        DateSend = (TextView) findViewById(R.id.product_send_show);

        submit = (Button) findViewById(R.id.insert_order_btn);
        insertOrder = new Order();
        mHelper = new DataBaseHelper(this);
        list = mHelper.readAllProducts();
        for (int i = 0; i < list.size(); i++) {
            product_list.add(list.get(i).getProduct_name());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, product_list);
        productName.setAdapter(adapter);
        insertOrder = new Order();
        CurrentDay = new GregorianCalendar();
        final int current_year = CurrentDay.get(Calendar.YEAR);
        final int current_month = CurrentDay.get(Calendar.MONTH) + 1;
        final int current_day = CurrentDay.get(Calendar.DAY_OF_MONTH);
        DateCreate.setText(current_day + "/" + current_month + "/" + current_year);
        DateSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int sendYear = cal.get(Calendar.YEAR);
                int sendMonth = cal.get(Calendar.MONTH);
                int sendDay = cal.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dialog = new DatePickerDialog(Add_Order_Activity.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener,
                        sendYear, sendMonth, sendDay);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });
        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;
                insertOrder.setDay_send(dayOfMonth);
                insertOrder.setMonth_send(month);
                insertOrder.setYear_send(year);
                DateSend.setText(insertOrder.getDay_send() + "/" + insertOrder.getMonth_send() + "/" + insertOrder.getYear_send());
            }
        };
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Add_Order_Activity.this);
                //แจ้งเตือนเพิ่มข้อมูล ส่วนที่เป็น Title
                builder.setTitle("Add this Order");
                //แจ้งเตือนเพิ่มข้อมูล ส่วนที่เป็น Message
                builder.setMessage(getString(R.string.Insert_product_message));
                //ปุ่ม OK
                builder.setPositiveButton(getString(android.R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                insertOrder.setOrder_id(mHelper.getCountOrder() + 1);
                                insertOrder.setOrder_name(orderName.getText().toString());
                                insertOrder.setCustomer_name(customerfirstName.getText().toString());
                                insertOrder.setCustomer_surname(customerlastName.getText().toString());
                                insertOrder.setCustomer_address(customerAddress.getText().toString());
                                insertOrder.setCustomer_phone(customerPhone.getText().toString());
                                insertOrder.setOrder_product(productName.getSelectedItem().toString());
                                insertOrder.setQuantity(Integer.parseInt((productQuantity.getText().toString())));
                                for (int i = 0; i < list.size(); i++) {
                                    if (insertOrder.getOrder_product().equals(list.get(i).getProduct_name())) {
                                        insertOrder.setTotal_price(list.get(i).getPrice() * insertOrder.getQuantity());
                                    }
                                }
                                insertOrder.setDay_order(current_day);
                                insertOrder.setMonth_order(current_month);
                                insertOrder.setYear_order(current_year);
                                insertOrder.setOrder_status("Incomplete");
                                mHelper.addOrder(insertOrder);
                            }
                        }
                );
                //ปุ่ม Cancel
                builder.setNegativeButton(getString(android.R.string.cancel), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.show();
            }
        });
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

        @Override
        public boolean onOptionsItemSelected(MenuItem item) {
            int id=item.getItemId();
            if(id==android.R.id.home){
                //end the activity
                this.finish();
            }
            return super.onOptionsItemSelected(item);

        }
}

