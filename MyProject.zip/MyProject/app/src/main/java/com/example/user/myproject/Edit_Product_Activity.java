package com.example.user.myproject;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Edit_Product_Activity extends AppCompatActivity {
    private ImageButton product_img;
    private EditText product_name;
    private EditText product_detail;
    private EditText price;
    private Button save_btn;
    private DataBaseHelper mHelper;
    private int REQUSE_CODE = 1;
    private Bitmap Image;
    private static int flag=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit__product_);

        mHelper=new DataBaseHelper(this);
        final int position=getIntent().getIntExtra("key",0);
        final Product mProduct=mHelper.getSearchedRecord(position);
        product_img=(ImageButton)findViewById(R.id.edit_product_image);
        product_name=(EditText)findViewById(R.id.edit_product_name);
        product_detail=(EditText)findViewById(R.id.edit_product_detail);
        price=(EditText)findViewById(R.id.edit_product_price);
        save_btn=(Button)findViewById(R.id.save_button);
        product_img.setImageBitmap(Product.getImage(mProduct.getProduct_imageBytes()));
        product_name.setText(mProduct.getProduct_name());
        product_detail.setText(mProduct.getProduct_detail());
        price.setText(String.valueOf(mProduct.getPrice()));

        product_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent itn=new Intent();
                itn.setType("image/*");
                itn.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(itn,"Select Image"),REQUSE_CODE);
            }
        });
        mProduct.setProduct_name(product_name.getText().toString());
        mProduct.setProduct_detail(product_detail.getText().toString());
        mProduct.setPrice(Double.parseDouble(price.getText().toString()));
        save_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(flag==1){
                    mProduct.setProduct_imageBytes(Product.getBytes(Image));
                }
                mProduct.setProduct_name(product_name.getText().toString());
                mProduct.setProduct_detail(product_detail.getText().toString());
                mProduct.setPrice(Double.parseDouble(price.getText().toString()));
                mHelper.editProduct(mProduct);
                finish();
            }
        });
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==REQUSE_CODE && resultCode==RESULT_OK && data!=null && data.getData()!=null){
            Uri uri=data.getData();
            try {
                Image=MediaStore.Images.Media.getBitmap(getContentResolver(),uri);
                flag=1;
                product_img.setImageBitmap(Image);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if(id==android.R.id.home){
            //end the activity
            this.finish();
        }
        return super.onOptionsItemSelected(item);

    }

}
