package com.example.user.myproject;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

public class Edit_Order_Activity extends AppCompatActivity {
    public static final String TAG="myTag";
    private EditText orderName;
    private EditText customerfirstName;
    private EditText customerlastName;
    private EditText customerAddress;
    private EditText customerPhone;
    private Spinner productName;
    private EditText productQuantity;
    private TextView DateCreate;
    private TextView DateSend;
    private Spinner stat;
    private Button save;
    private DataBaseHelper mHelper;
    private Order mOrder;
    private List<Product> list=new ArrayList<>();
    private List<String> product_list=new ArrayList<>();
    private List<String> stat_list=new ArrayList<>();
    private GregorianCalendar CurrentDay;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit__order_);
        orderName = (EditText) findViewById(R.id.edit_order_name);
        customerfirstName = (EditText) findViewById(R.id.edit_customer_firstname);
        customerlastName = (EditText) findViewById(R.id.edit_customer_lastname);
        customerAddress = (EditText) findViewById(R.id.edit_customer_address);
        customerPhone = (EditText) findViewById(R.id.edit_customer_phone);
        productName = (Spinner) findViewById(R.id.edit_product_list);
        productQuantity = (EditText) findViewById(R.id.edit_quantity);
        DateCreate = (TextView) findViewById(R.id.edit_product_date_order_show);
        DateSend = (TextView) findViewById(R.id.edit_product_send_show);
        stat = (Spinner) findViewById(R.id.edit_order_status);
        save = (Button) findViewById(R.id.save_btn);
        mHelper = new DataBaseHelper(this);
        int position = getIntent().getIntExtra("key", 0);
        final Order mOrder = mHelper.getSearchedOrderRecord(position);
        orderName.setText(mOrder.getOrder_name());
        customerfirstName.setText(mOrder.getCustomer_name());
        customerlastName.setText(mOrder.getCustomer_surname());
        customerAddress.setText(mOrder.getCustomer_address());
        customerPhone.setText(mOrder.getCustomer_phone());
        list = mHelper.readAllProducts();
        for (int i = 0; i < list.size(); i++) {
            product_list.add(list.get(i).getProduct_name());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, product_list);
        productName.setAdapter(adapter);
        int dropdownIndex=product_list.indexOf(mOrder.getOrder_product());
        productName.setSelection(dropdownIndex);
        productQuantity.setText(String.valueOf(mOrder.getQuantity()));
        DateCreate.setText(mOrder.getDay_order() + "/" + mOrder.getMonth_order() + "/" + mOrder.getYear_order());
        DateSend.setText(mOrder.getDay_send() + "/" + mOrder.getMonth_send() + "/" + mOrder.getYear_send());
        stat_list.add("Incomplete");
        stat_list.add("Complete");
        ArrayAdapter<String> stat_adapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, stat_list);
        stat.setAdapter(stat_adapter);
        int statIndex=stat_list.indexOf(mOrder.getOrder_status());
        stat.setSelection(statIndex);
        DateSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int sendYear = cal.get(Calendar.YEAR);
                int sendMonth = cal.get(Calendar.MONTH);
                int sendDay = cal.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dialog = new DatePickerDialog(Edit_Order_Activity.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener,
                        sendYear, sendMonth, sendDay);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });
        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;
                mOrder.setDay_send(dayOfMonth);
                mOrder.setMonth_send(month);
                mOrder.setYear_send(year);
                DateSend.setText(mOrder.getDay_send() + "/" + mOrder.getMonth_send() + "/" + mOrder.getYear_send());
            }
        };
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mOrder.setOrder_name(orderName.getText().toString());
                mOrder.setCustomer_name(customerfirstName.getText().toString());
                mOrder.setCustomer_surname(customerlastName.getText().toString());
                mOrder.setCustomer_address(customerAddress.getText().toString());
                mOrder.setCustomer_phone(customerPhone.getText().toString());
                mOrder.setOrder_product(productName.getSelectedItem().toString());
                mOrder.setQuantity(Integer.parseInt((productQuantity.getText().toString())));
                for (int i = 0; i < list.size(); i++) {
                    if (mOrder.getOrder_product().equals(list.get(i).getProduct_name())) {
                        mOrder.setTotal_price(list.get(i).getPrice() * mOrder.getQuantity());
                    }
                }
                mOrder.setOrder_status(stat.getSelectedItem().toString());
                mHelper.editOrder(mOrder);
                finish();

            }
        });
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if(id==android.R.id.home){
            //end the activity
            this.finish();
        }
        return super.onOptionsItemSelected(item);

    }
}
