package com.example.user.myproject;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;

import java.util.ArrayList;
import java.util.List;

public class Chart_Activity extends AppCompatActivity {
    public static final String TAG="myTag";
    private List<Order> order_list;
    private List<Product> product_list;
    private DataBaseHelper mHelper;
    private List<String> product_name;
    private List<Integer> product_quantity;
    private List<Float> total_product_price;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart_);
        PieChart chart=(PieChart)findViewById(R.id.PieChart);
        chart.setRotationEnabled(true);
        chart.setHoleRadius(25f);
        chart.setTransparentCircleAlpha(0);
        //chart.setCenterText("SUMATION");
        //chart.setCenterTextSize(20);
        AddDataToChart(chart);
        chart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                Log.i(TAG,e.toString());
                Log.i(TAG,h.toString());
                int pos1=e.toString().indexOf("(sum): ");
                String sale=e.toString().substring(pos1+7);

                for(int i=0;i<total_product_price.size();i++){
                    if(total_product_price.get(i)==Float.parseFloat(sale)){
                        pos1=i;
                        break;
                    }
                }
                Toast.makeText(Chart_Activity.this,"Product is : "+product_name.get(pos1)+"\n"+
                        "Quantity is : "+product_quantity.get(pos1)+" ea \n"+
                        "Total Price is : "+total_product_price.get(pos1)+" Bath.",Toast.LENGTH_LONG).show();

            }

            @Override
            public void onNothingSelected() {

            }
        });
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if(id==android.R.id.home){
            //end the activity
            this.finish();
        }
        return super.onOptionsItemSelected(item);

    }
    private void AddDataToChart(PieChart chart){
        mHelper=new DataBaseHelper(this);
        product_name=new ArrayList<>();
        product_quantity=new ArrayList<>();
        total_product_price=new ArrayList<>();
        order_list=mHelper.readAllOrders();
        product_list=mHelper.readAllProducts();
        /*for(int i=0;i<product_list.size();i++){
            product_name.add(product_list.get(i).getProduct_name());
            product_quantity.add(0);
            total_product_price.add((float)0);
        }*/
        product_name.add(order_list.get(0).getOrder_product());
        product_quantity.add(0);
        total_product_price.add((float)0);
        for (int i=1;i<order_list.size();i++){
            if(product_name.indexOf(order_list.get(i).getOrder_product())==-1){
                product_name.add(order_list.get(i).getOrder_product());
                product_quantity.add(0);
                total_product_price.add((float)0);
            }
        }
        for(int i=0;i<product_name.size();i++){
            Log.i(TAG,"new "+product_name.size()+" / "+product_name.get(i)+"- Quantity : "+product_quantity.get(i)+"- Total Price : "+total_product_price.get(i));
        }
        for (int i=0;i<order_list.size();i++){
            Log.i(TAG,"this is orderlist"+order_list.get(i).getOrder_product()+" this is i at : "+i);
            for(int j=0;j<product_name.size();j++){
                if(order_list.get(i).getOrder_product().equals(product_name.get(j))&&order_list.get(i).getOrder_status().equals("Complete")){
                    product_quantity.set(j,product_quantity.get(j)+order_list.get(i).getQuantity());
                    total_product_price.set(j,Float.valueOf(String.valueOf(order_list.get(i).getTotal_price()))+total_product_price.get(j));
                    break;
                }
            }
        }
        for(int i=0;i<product_name.size();i++){
            if(product_quantity.get(i)==0){
                product_name.remove(i);
                product_quantity.remove(i);
                total_product_price.remove(i);
            }
        }
        ArrayList<PieEntry> yEntrys=new ArrayList<>();
        for (int i=0;i<total_product_price.size();i++){
            yEntrys.add(new PieEntry(total_product_price.get(i),i));
        }
        Log.i(TAG,"working1");
        //create data set
        PieDataSet pieDataSet=new PieDataSet(yEntrys,"Total");
        pieDataSet.setSliceSpace(5);
        pieDataSet.setValueTextSize(15);
        //pieDataSet.setColor(Color.BLUE);
        pieDataSet.setValueTextColor(Color.BLACK);
        Log.i(TAG,"working2");

        //create legend chart
        Legend legend=chart.getLegend();
        legend.setForm(Legend.LegendForm.CIRCLE);
        legend.setPosition(Legend.LegendPosition.LEFT_OF_CHART);
        Log.i(TAG,"working3");
        //create pie data object
        PieData pieData=new PieData(pieDataSet);
        chart.setData(pieData);
        chart.invalidate();
        Log.i(TAG,"working4");
    }
}
