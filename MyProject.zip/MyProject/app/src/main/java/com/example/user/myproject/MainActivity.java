package com.example.user.myproject;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private Intent itn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        registerAlarm();
        ImageButton btn1=(ImageButton)findViewById(R.id.Main_product_add);
        btn1.setImageResource(R.drawable.add_product);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itn=new Intent(getApplicationContext(),Add_Activity.class);
                startActivity(itn);
            }
        });
        ImageButton btn2=(ImageButton)findViewById(R.id.Main_product);
        btn2.setImageResource(R.drawable.show_product);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itn=new Intent(getApplicationContext(),Product_List_Activity.class);
                startActivity(itn);
            }
        });

        ImageButton btn3=(ImageButton)findViewById(R.id.Main_order);
        btn3.setImageResource(R.drawable.show_order);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itn=new Intent(getApplicationContext(),Order_List_Activity.class);
                startActivity(itn);
            }
        });

        ImageButton btn4=(ImageButton)findViewById(R.id.Main_order_add);
        btn4.setImageResource(R.drawable.add_order);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itn=new Intent(getApplicationContext(),Add_Order_Activity.class);
                startActivity(itn);
            }
        });
        ImageButton btn5=(ImageButton)findViewById(R.id.chart_btn);
        btn5.setImageResource(R.drawable.chart);
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itn=new Intent(getApplicationContext(),Chart_Activity.class);
                startActivity(itn);
            }
        });



    }
    private void registerAlarm(){
        Calendar calendar=Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY,18);
        calendar.set(Calendar.MINUTE,30);
        calendar.set(Calendar.SECOND,0);
        Intent intent=new Intent(MainActivity.this,AlarmReceiver.class);
        PendingIntent pendingIntent=PendingIntent.getBroadcast(MainActivity.this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager am=(AlarmManager)this.getSystemService(this.ALARM_SERVICE);
        am.setRepeating(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);




    }
}
