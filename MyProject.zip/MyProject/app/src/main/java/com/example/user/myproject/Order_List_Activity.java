package com.example.user.myproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class Order_List_Activity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    public static final String TAG="myTag";
    private List<Order> list=new ArrayList<>();
    private DataBaseHelper mHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order__list_);
        mHelper=new DataBaseHelper(this);
        list=mHelper.readAllOrders();
        OrderAdapter adapter=new OrderAdapter(getApplicationContext(),list);
        ListView lv=(ListView)findViewById(R.id.Order_List);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(this);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if(id==android.R.id.home){
            //end the activity
            this.finish();
        }
        return super.onOptionsItemSelected(item);

    }
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent itn=new Intent(getApplicationContext(),Show_Order_Activity.class);
        itn.putExtra("key", position);
        startActivity(itn);

    }
}
