package com.example.user.myproject;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class Show_Order_Activity extends AppCompatActivity {
    private static final String Tag="myTag";
    private TextView order_name;
    private TextView customer_firstname;
    private TextView customer_lastname;
    private TextView customer_address;
    private TextView customer_phone;
    private TextView order_product;
    private TextView quantity;
    private TextView total;
    private TextView dateCreate;
    private TextView dateSend;
    private TextView Status;
    private Button delete_button;
    private Button edit_button;
    private DataBaseHelper mHelper;
    private int position;
    private Order mOrder;
    private List<Order> oldOrderList,newOrderList;
    private Intent itn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show__order_);
        mHelper=new DataBaseHelper(this);
        position=getIntent().getIntExtra("key",0);
        mOrder=mHelper.getSearchedOrderRecord(position);
        order_name=(TextView)findViewById(R.id.show_order_name);
        customer_firstname=(TextView)findViewById(R.id.show_customer_firstname);
        customer_lastname=(TextView)findViewById(R.id.show_customer_lastname);
        customer_address=(TextView)findViewById(R.id.show_customer_address);
        customer_phone=(TextView)findViewById(R.id.show_customer_phone);
        order_product=(TextView)findViewById(R.id.show_order_product);
        quantity=(TextView)findViewById(R.id.show_quantity);
        total=(TextView)findViewById(R.id.show_total);
        dateCreate=(TextView)findViewById(R.id.show_date_create);
        dateSend=(TextView)findViewById(R.id.show_date_send);
        Status=(TextView)findViewById(R.id.show_status);
        delete_button=(Button)findViewById(R.id.delete_order_btn);
        edit_button=(Button)findViewById(R.id.edit_order_btn);
        order_name.setText("ออเดอร์ :"+mOrder.getOrder_name());
        order_name.setTextColor(Color.BLACK);
        customer_firstname.setText("ชื่อ :"+mOrder.getCustomer_name());
        customer_firstname.setTextColor(Color.BLACK);
        customer_lastname.setText("นามสกุล :"+mOrder.getCustomer_surname());
        customer_lastname.setTextColor(Color.BLACK);
        customer_address.setText("ที่อยู่ :"+mOrder.getCustomer_address());
        customer_address.setTextColor(Color.BLACK);
        customer_phone.setText("เบอร์โทร :"+mOrder.getCustomer_phone());
        customer_phone.setTextColor(Color.BLACK);
        order_product.setText("สินค้า :"+mOrder.getOrder_product());
        order_product.setTextColor(Color.BLACK);
        quantity.setText("จำนวน :"+mOrder.getQuantity());
        quantity.setTextColor(Color.BLACK);
        total.setText("ราคาทั้งหมด :"+mOrder.getTotal_price()+" บาท");
        total.setTextColor(Color.BLACK);
        dateCreate.setText("วันที่สั่ง :"+mOrder.getDay_order()+"/"+mOrder.getMonth_order()+"/"+mOrder.getYear_order());
        dateCreate.setTextColor(Color.GREEN);
        dateSend.setText("วันที่ส่ง :"+mOrder.getDay_send()+"/"+mOrder.getMonth_send()+"/"+mOrder.getYear_send());
        dateSend.setTextColor(Color.RED);
        Status.setText("สถานะ :"+mOrder.getOrder_status());
        if(mOrder.getOrder_status().equals("Complete")){
            Status.setTextColor(Color.GREEN);
        }
        else{
            Status.setTextColor(Color.RED);
        }
        delete_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Show_Order_Activity.this);
                //แจ้งเตือนเพิ่มข้อมูล ส่วนที่เป็น Title
                builder.setTitle("Delete this order?");
                //แจ้งเตือนเพิ่มข้อมูล ส่วนที่เป็น Message
                builder.setMessage("Are you sure?");

                builder.setPositiveButton(getString(android.R.string.ok), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mHelper.deleteOrder(mOrder.getOrder_id());
                        oldOrderList=mHelper.readAllOrders();
                        newOrderList=mHelper.readAllOrders();
                        for(int i=0;i<newOrderList.size();i++){
                            newOrderList.get(i).setOrder_id(i+1);
                            mHelper.updateListOrders(oldOrderList.get(i),newOrderList.get(i));
                        }
                        finish();
                    }
                });
                //ปุ่ม Cancel
                builder.setNegativeButton(getString(android.R.string.cancel), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.show();
            }
        });
        edit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent itn=new Intent(getApplicationContext(),Edit_Order_Activity.class);
                itn.putExtra("key",position);
                startActivity(itn);

            }
        });
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if(id==android.R.id.home){
            //end the activity
            this.finish();
        }
        return super.onOptionsItemSelected(item);

    }
}
