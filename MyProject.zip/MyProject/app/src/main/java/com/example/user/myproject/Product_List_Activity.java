package com.example.user.myproject;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Product_List_Activity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    public static final String TAG="myTag";
    private List<Product> list=new ArrayList<>();
    private DataBaseHelper mHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product__list_);
        mHelper=new DataBaseHelper(this);
        list=mHelper.readAllProducts();
        ProductAdapter adapter=new ProductAdapter(this,list);
        ListView lv=(ListView)findViewById(R.id.Product_List);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(this);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if(id==android.R.id.home){
            //end the activity
            this.finish();
        }
        return super.onOptionsItemSelected(item);

    }
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent itn=new Intent(getApplicationContext(),Show_Activity.class);
        itn.putExtra("key", position);
        startActivity(itn);

    }
}
